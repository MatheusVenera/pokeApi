import { ResponseLink } from './response-link';

describe('ResponseLink', () => {
  it('should create an instance', () => {
    expect(new ResponseLink()).toBeTruthy();
  });
});
