import { Abilities } from './abilities';

describe('Abilities', () => {
  it('should create an instance', () => {
    expect(new Abilities()).toBeTruthy();
  });
});
