export const environment = {
  production: true,
  urlPokeApiBase: 'https://pokeapi.co/api/v2'
};
